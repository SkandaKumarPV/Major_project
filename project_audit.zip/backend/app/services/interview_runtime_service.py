from sqlalchemy import text

from backend.app.database.database import SessionLocal
from backend.app.database.resume_database import ResumeSessionLocal
from backend.app.database.resume_models import (
    CandidateResume,
    InterviewSessionRecord,
)
from backend.app.services.interview_session_service import (
    mark_interview_started,
    update_interview_progress,
)
from backend.app.services.resume_discussion_service import (
    ResumeDiscussionService,
    ResumeDiscussionStage,
)
from backend.app.services.technical_interview_service import (
    TechnicalInterviewService,
    TechnicalInterviewError,
)
from backend.app.services.question_bank_service import (
    QuestionBankService,
)


STAGE_2_TRANSITION_MESSAGE = (
    "Thank you for sharing that. That completes the introduction "
    "and project discussion. We will now move on to the technical "
    "interview."
)


class InterviewRuntimeError(Exception):
    """Raised when a persistent interview cannot be initialized."""


class InterviewRuntimeService:
    """
    Loads and manages the backend-owned interview runtime.

    Stage 1:
        Introduction and resume/project discussion.

    Stage 2:
        Adaptive three-question technical interview.
    """

    def __init__(self, room_name: str, llm_provider):
        self.room_name = room_name
        self.llm_provider = llm_provider

        self.session_id = None
        self.candidate_id = None

        self.discussion = None
        self.technical_interview = None

        self.resume_data = None
        self.role_data = None

        self._load_runtime()

    def _load_runtime(self):
        with ResumeSessionLocal() as resume_db:
            interview = (
                resume_db.query(InterviewSessionRecord)
                .filter(
                    InterviewSessionRecord.room_name
                    == self.room_name
                )
                .one_or_none()
            )

            if interview is None:
                raise InterviewRuntimeError(
                    f"No interview record exists for room {self.room_name}."
                )

            if interview.status == "ended":
                raise InterviewRuntimeError(
                    "This interview has already ended."
                )

            if not interview.resume_id:
                raise InterviewRuntimeError(
                    "The interview has no selected resume."
                )

            resume = (
                resume_db.query(CandidateResume)
                .filter(
                    CandidateResume.id == interview.resume_id,
                    CandidateResume.candidate_id
                    == interview.candidate_id,
                )
                .one_or_none()
            )

            if resume is None:
                raise InterviewRuntimeError(
                    "The selected resume could not be found."
                )

            resume_data = resume.structured_data
            self.resume_data = resume_data

            if not isinstance(resume_data, dict):
                raise InterviewRuntimeError(
                    "The selected resume has no valid extracted data."
                )

            role_data = self._load_role(interview.role_id)
            self.role_data = role_data

            transcript = self._load_transcript(
                resume_db,
                interview.id,
                interview.candidate_id,
            )

            structured_memory = interview.structured_memory or {}

            stage_state = structured_memory.get(
                "resume_discussion",
                {},
            )

            technical_state = structured_memory.get(
                "technical_interview",
                {},
            )

            self.session_id = interview.id
            self.candidate_id = interview.candidate_id

            self.discussion = ResumeDiscussionService(
                llm_provider=self.llm_provider,
                resume_data=resume_data,
                role_data=role_data,
                conversation_history=transcript,
                initial_state=stage_state,
            )

            if (
                interview.current_stage
                == ResumeDiscussionStage.TECHNICAL_INTERVIEW.value
            ):
                self._create_technical_service(
                    technical_state,
                    transcript,
                )

            mark_interview_started(
                resume_db,
                session_id=interview.id,
                candidate_id=interview.candidate_id,
            )

    def _load_role(self, role_id) -> dict:
        """Resolve the selected role by its stored database ID."""

        if role_id is None:
            raise InterviewRuntimeError(
                "The interview session has no selected role."
            )

        with SessionLocal() as role_db:
            role = role_db.execute(
                text(
                    "SELECT id, role_name, role_details "
                    "FROM roles WHERE CAST(id AS TEXT) = :role_id"
                ),
                {
                    "role_id": str(role_id),
                },
            ).mappings().first()

            if role is None:
                raise InterviewRuntimeError(
                    f"Selected role ID {role_id!r} was not found "
                    "in the role database."
                )

            technologies = role_db.execute(
                text(
                    "SELECT technology FROM role_technologies "
                    "WHERE role_id = :role_id ORDER BY id"
                ),
                {
                    "role_id": role["id"],
                },
            ).scalars().all()

            return {
                "id": str(role["id"]),
                "role_name": role["role_name"],
                "role_details": role["role_details"],
                "technologies": list(technologies),
            }

    @staticmethod
    def _load_transcript(
        db,
        session_id,
        candidate_id,
    ) -> list:
        from backend.app.services.interview_session_service import (
            get_interview_transcript,
        )

        messages = get_interview_transcript(
            db,
            session_id=session_id,
            candidate_id=candidate_id,
        )

        history = []

        for message in messages:
            speaker = message.speaker

            if speaker in {
                "assistant",
                "interviewer",
            }:
                speaker = "interviewer"

            elif speaker == "candidate":
                speaker = "candidate"

            else:
                continue

            history.append({
                "speaker": speaker,
                "text": message.message_text,
            })

        return history

    def _create_technical_service(
        self,
        initial_state=None,
        history=None,
    ):
        """
        Build the Stage 2 service.

        Main questions are retrieved from the role question bank.
        Follow-ups are generated by the LLM and are never queried
        from the question bank.
        """

        def select_question(
            difficulty,
            excluded_ids,
        ):
            with SessionLocal() as role_db:
                service = QuestionBankService(role_db)

                return service.select_random_unused_question(
                    self.role_data["role_name"],
                    difficulty,
                    excluded_ids=excluded_ids,
                )

        self.technical_interview = TechnicalInterviewService(
            llm_provider=self.llm_provider,
            question_selector=select_question,
            role_data=self.role_data,
            resume_data=self.resume_data,
            initial_state=initial_state or {},
            conversation_history=(
                history
                or self.discussion.conversation_history
            ),
        )

    def start(self) -> str:
        """Start Stage 1 or resume the active Stage 2 question."""

        if (
            self.discussion.stage
            == ResumeDiscussionStage.NOT_STARTED
        ):
            opening = self.discussion.start()
            self._persist_progress()
            return opening

        if (
            self.discussion.stage
            == ResumeDiscussionStage.TECHNICAL_INTERVIEW
        ):
            if self.technical_interview is None:
                with ResumeSessionLocal() as db:
                    record = (
                        db.query(InterviewSessionRecord)
                        .filter(
                            InterviewSessionRecord.id
                            == self.session_id,
                            InterviewSessionRecord.candidate_id
                            == self.candidate_id,
                        )
                        .one()
                    )

                    state = (
                        record.structured_memory or {}
                    ).get(
                        "technical_interview",
                        {},
                    )

                self._create_technical_service(
                    state,
                    self.discussion.conversation_history,
                )

            prompt = self.technical_interview.start()

            self._persist_technical_progress()

            return prompt

        # Reconnect must replay the most recent committed interviewer prompt.
        for item in reversed(
            self.discussion.conversation_history
        ):
            if item.get("speaker") == "interviewer":
                return item.get(
                    "text",
                    STAGE_2_TRANSITION_MESSAGE,
                )

        raise InterviewRuntimeError(
            "Interview was already started, but no previous "
            "interviewer prompt exists."
        )

    def process_candidate_answer(
        self,
        candidate_answer: str,
    ) -> str:
        """Route one finalized candidate turn to the active stage."""

        if (
            self.discussion.stage
            == ResumeDiscussionStage.TECHNICAL_INTERVIEW
        ):
            if self.technical_interview is None:
                with ResumeSessionLocal() as db:
                    record = (
                        db.query(InterviewSessionRecord)
                        .filter(
                            InterviewSessionRecord.id
                            == self.session_id,
                            InterviewSessionRecord.candidate_id
                            == self.candidate_id,
                        )
                        .one()
                    )

                    state = (
                        record.structured_memory or {}
                    ).get(
                        "technical_interview",
                        {},
                    )

                self._create_technical_service(
                    state,
                    self.discussion.conversation_history,
                )

            response = (
                self.technical_interview.process_answer(
                    candidate_answer
                )
            )

            self._persist_technical_progress()

            return response

        result = self.discussion.process_answer(
            candidate_answer
        )

        if result is None:
            # Persist Stage 1 completion before creating Stage 2.
            self._persist_progress()

            self._create_technical_service()

            first_question = self.technical_interview.start()

            # Transition and first question are delivered as one spoken turn.
            combined = (
                f"{STAGE_2_TRANSITION_MESSAGE} "
                f"{first_question}"
            )

            if self.technical_interview.conversation_history:
                self.technical_interview.conversation_history[
                    -1
                ]["text"] = combined

            self._persist_technical_progress()

            return combined

        self._persist_progress()

        return result

    def _persist_technical_progress(self):
        """Persist Stage 2 state and progress."""

        if self.technical_interview is None:
            return

        state = self.technical_interview.export_state()

        with ResumeSessionLocal() as db:
            interview = (
                db.query(InterviewSessionRecord)
                .filter(
                    InterviewSessionRecord.id
                    == self.session_id,
                    InterviewSessionRecord.candidate_id
                    == self.candidate_id,
                )
                .one_or_none()
            )

            if interview is None:
                raise InterviewRuntimeError(
                    "Interview session disappeared while saving Stage 2 progress."
                )

            memory = dict(
                interview.structured_memory or {}
            )

            memory["technical_interview"] = state

            completed_stages = list(
                interview.completed_stages or []
            )

            if (
                state["stage_complete"]
                and "technical_interview"
                not in completed_stages
            ):
                completed_stages.append(
                    "technical_interview"
                )

            current_question = (
                state.get("current_question") or {}
            )

            update_interview_progress(
                db,
                session_id=self.session_id,
                candidate_id=self.candidate_id,
                current_stage=(
                    "completed"
                    if state["stage_complete"]
                    else ResumeDiscussionStage.TECHNICAL_INTERVIEW.value
                ),
                current_main_question_id=(
                    str(current_question.get("id"))
                    if current_question
                    else None
                ),
                used_main_question_ids=(
                    state["used_main_question_ids"]
                ),
                follow_up_count=(
                    state["current_follow_up_count"]
                ),
                completed_question_ids=(
                    state["completed_main_question_ids"]
                ),
                completed_stages=completed_stages,
                structured_memory=memory,
            )

    def _persist_progress(self):
        """Persist Stage 1 state."""

        state = self.discussion.export_state()

        with ResumeSessionLocal() as db:
            interview = (
                db.query(InterviewSessionRecord)
                .filter(
                    InterviewSessionRecord.id
                    == self.session_id,
                    InterviewSessionRecord.candidate_id
                    == self.candidate_id,
                )
                .one_or_none()
            )

            if interview is None:
                raise InterviewRuntimeError(
                    "Interview session disappeared while saving progress."
                )

            memory = dict(
                interview.structured_memory or {}
            )

            memory["resume_discussion"] = state

            completed_stages = list(
                interview.completed_stages or []
            )

            if (
                self.discussion.stage
                == ResumeDiscussionStage.TECHNICAL_INTERVIEW
                and "resume_discussion"
                not in completed_stages
            ):
                completed_stages.append(
                    "resume_discussion"
                )

            update_interview_progress(
                db,
                session_id=self.session_id,
                candidate_id=self.candidate_id,
                current_stage=self.discussion.stage.value,
                follow_up_count=(
                    self.discussion.cross_question_count
                ),
                completed_stages=completed_stages,
                structured_memory=memory,
            )